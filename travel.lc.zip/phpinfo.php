<?php echo phpinfo(); ?>
